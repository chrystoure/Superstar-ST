import React from 'react';
import { SERVICES, ServiceItem, COMPANY_INFO } from '../data/catalog';
import { CheckCircle2, ArrowRight, Sparkles, Store, Users, ShoppingBag, Truck } from 'lucide-react';
import { PageId } from '../components/Navbar';

interface ServicesPageProps {
  onNavigate: (page: PageId, extraParam?: string) => void;
}

export const ServicesPage: React.FC<ServicesPageProps> = ({ onNavigate }) => {
  const handleServiceInquiry = (service: ServiceItem) => {
    onNavigate('contact', service.contactSubject);
  };

  return (
    <div className="space-y-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      
      {/* 1. Services Header */}
      <section className="text-center max-w-3xl mx-auto space-y-6">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 text-xs font-semibold text-cyan-300">
          <Sparkles className="w-3.5 h-3.5 text-[#00f0ff]" />
          <span>Nos Prestations & Solutions Mode</span>
        </div>

        <h1 className="text-4xl sm:text-5xl font-black text-white font-display tracking-tight text-balance">
          Des Services Taillés pour la <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-cyan-200 to-[#00f0ff]">Jeunesse</span> et les <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-cyan-200 to-[#00f0ff]">Petites Entreprises</span>
        </h1>

        <p className="text-base sm:text-lg text-neutral-300 leading-relaxed font-normal">
          Que vous souhaitiez renouveler votre garde-robe personnelle avec des pièces streetwear exclusives ou propulser votre boutique de vente en ligne à Abidjan, découvrez notre accompagnement complet.
        </p>
      </section>

      {/* 2. Main Services Grid */}
      <section className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {SERVICES.map((srv, index) => {
          const isB2B = srv.target.includes('Petites Entreprises');

          return (
            <div
              key={srv.id}
              className={`p-8 sm:p-10 rounded-2xl bg-[#0c0e14] border transition-all duration-300 flex flex-col justify-between group ${
                isB2B
                  ? 'border-cyan-500/40 shadow-[0_0_25px_rgba(0,240,255,0.08)]'
                  : 'border-white/10 hover:border-white/20'
              }`}
            >
              <div className="space-y-6">
                
                {/* Header Tag & Target Audience */}
                <div className="flex items-center justify-between gap-4">
                  <span className={`text-[11px] font-bold uppercase tracking-wider px-2.5 py-1 rounded ${
                    isB2B ? 'bg-cyan-500/20 text-[#00f0ff] border border-cyan-400/30' : 'bg-white/10 text-neutral-300'
                  }`}>
                    {srv.target}
                  </span>
                  <span className="text-xs font-mono text-neutral-500">
                    0{index + 1}.
                  </span>
                </div>

                <div>
                  <h3 className="text-2xl font-bold text-white font-display mb-1 group-hover:text-cyan-300 transition-colors">
                    {srv.title}
                  </h3>
                  <div className="text-xs text-neutral-400 font-medium">
                    {srv.subtitle}
                  </div>
                </div>

                <p className="text-sm text-neutral-300 leading-relaxed">
                  {srv.description}
                </p>

                {/* Benefits List */}
                <div className="space-y-2.5 pt-2">
                  <div className="text-xs font-semibold uppercase tracking-wider text-white">
                    Avantages clés :
                  </div>
                  <ul className="space-y-2">
                    {srv.benefits.map((b, bIdx) => (
                      <li key={bIdx} className="flex items-start gap-2.5 text-xs sm:text-sm text-neutral-300">
                        <CheckCircle2 className="w-4 h-4 text-[#00f0ff] shrink-0 mt-0.5" />
                        <span>{b}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Action Button */}
              <div className="pt-8 mt-8 border-t border-white/10">
                <button
                  onClick={() => handleServiceInquiry(srv)}
                  className={`w-full py-3.5 px-5 rounded-lg font-bold text-xs uppercase tracking-wider transition-all flex items-center justify-center gap-2 cursor-pointer ${
                    isB2B
                      ? 'bg-[#00f0ff] hover:bg-cyan-300 text-black shadow-md'
                      : 'bg-white/10 hover:bg-white/15 text-white'
                  }`}
                >
                  <span>{srv.ctaLabel}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          );
        })}
      </section>

      {/* 3. Focus Section: Comment Commander ou Devenir Revendeur ? */}
      <section className="p-8 sm:p-12 rounded-2xl bg-[#080a0f] border border-white/10">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <div className="text-xs uppercase tracking-widest text-[#00f0ff] font-bold mb-2">
            Processus Simple & Rapide
          </div>
          <h2 className="text-3xl font-extrabold text-white font-display">
            Comment se déroule votre commande ?
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative">
          <div className="space-y-3">
            <div className="w-10 h-10 rounded-full bg-[#00f0ff] text-black font-extrabold text-sm flex items-center justify-center font-display">
              1
            </div>
            <h4 className="text-lg font-bold text-white font-display">
              Soumettez votre demande
            </h4>
            <p className="text-xs sm:text-sm text-neutral-400 leading-relaxed">
              Via notre formulaire de contact ou sur WhatsApp. Précisez les pièces ou le pack revendeur qui vous intéresse, ainsi que votre commune à Abidjan.
            </p>
          </div>

          <div className="space-y-3">
            <div className="w-10 h-10 rounded-full bg-[#00f0ff] text-black font-extrabold text-sm flex items-center justify-center font-display">
              2
            </div>
            <h4 className="text-lg font-bold text-white font-display">
              Validation & Réservation
            </h4>
            <p className="text-xs sm:text-sm text-neutral-400 leading-relaxed">
              Nous vous confirmons immédiatement la disponibilité en stock, vos pointures/tailles exactes, et fixons le créneau de livraison adapté.
            </p>
          </div>

          <div className="space-y-3">
            <div className="w-10 h-10 rounded-full bg-[#00f0ff] text-black font-extrabold text-sm flex items-center justify-center font-display">
              3
            </div>
            <h4 className="text-lg font-bold text-white font-display">
              Livraison & Réception
            </h4>
            <p className="text-xs sm:text-sm text-neutral-400 leading-relaxed">
              Notre coursier livre votre colis à l'adresse de votre choix à Abidjan sous 24h. Vous inspectez votre commande et réglez en toute sécurité.
            </p>
          </div>
        </div>

        <div className="mt-12 text-center">
          <button
            onClick={() => onNavigate('contact', 'Demande générale suite à la page Services')}
            className="px-8 py-3.5 bg-[#00f0ff] hover:bg-cyan-300 text-black font-bold text-xs uppercase tracking-wider rounded-lg transition-all shadow-[0_0_20px_rgba(0,240,255,0.3)] cursor-pointer"
          >
            Faire une demande de service
          </button>
        </div>
      </section>

    </div>
  );
};
