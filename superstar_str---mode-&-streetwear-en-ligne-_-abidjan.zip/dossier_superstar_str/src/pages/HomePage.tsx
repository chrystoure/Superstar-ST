import React, { useState } from 'react';
import { ArrowRight, CheckCircle2, Sparkles, ShieldCheck, Truck, Zap, ShoppingBag, Store, Users, ArrowUpRight } from 'lucide-react';
import { PRODUCTS, Product, COMPANY_INFO, TESTIMONIALS } from '../data/catalog';
import { ContactForm } from '../components/ContactForm';
import { BrandLogo } from '../components/BrandLogo';
import { PageId } from '../components/Navbar';

interface HomePageProps {
  onNavigate: (page: PageId, extraParam?: string) => void;
  onSelectProductForContact: (product: Product) => void;
}

export const HomePage: React.FC<HomePageProps> = ({ onNavigate, onSelectProductForContact }) => {
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'vetements' | 'chaussures' | 'accessoires' | 'packs-pro'>('all');

  const filteredProducts = selectedCategory === 'all'
    ? PRODUCTS
    : PRODUCTS.filter((p) => p.category === selectedCategory);

  const handleOrderProduct = (product: Product) => {
    onSelectProductForContact(product);
    onNavigate('contact', `Commande de : ${product.name} (${product.price})`);
  };

  return (
    <div className="space-y-24 sm:space-y-32">
      
      {/* 1. HERO SECTION - HIGH CONVERSION & LOGO INSPIRED */}
      <section className="relative pt-6 sm:pt-12 pb-16 overflow-hidden">
        {/* Ambient Neon Atmosphere matching the logo */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[350px] bg-gradient-to-b from-[#00f0ff]/20 via-[#0066ff]/10 to-transparent blur-3xl pointer-events-none rounded-full" />
        <div className="absolute top-24 left-10 w-72 h-72 bg-blue-600/10 blur-[120px] pointer-events-none rounded-full" />

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          
          {/* Top Brand Logo Banner */}
          <div className="flex flex-col items-center justify-center mb-8">
            <BrandLogo variant="full" showTagline={true} className="w-full max-w-md" />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center mt-6">
            
            {/* Left Column: Conversion Pitch */}
            <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 text-xs font-semibold text-cyan-300">
                <span className="w-2 h-2 rounded-full bg-[#00f0ff] animate-ping" />
                <span>Nouvelle Collection Streetwear & Offres Revendeurs 2026</span>
              </div>

              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-white font-display tracking-tight leading-[1.08] text-balance">
                Le Streetwear & la Mode Nouvelle Génération à <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-cyan-200 to-[#00f0ff]">Abidjan</span>
              </h1>

              <p className="text-base sm:text-lg text-neutral-300 max-w-2xl mx-auto lg:mx-0 leading-relaxed font-normal">
                Vêtements haut de gamme, sneakers convoitées et accessoires urbains. Vente au détail pour les passionnés de mode et packs d’approvisionnement sur-mesure pour les <strong className="text-white">petites entreprises et revendeurs</strong> en Côte d’Ivoire.
              </p>

              {/* Conversion CTAs */}
              <div className="flex flex-col sm:flex-row items-center justify-center lg:justify-start gap-4 pt-2">
                <button
                  onClick={() => {
                    const el = document.getElementById('catalogue-section');
                    el?.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-3 px-7 py-4 text-sm font-bold uppercase tracking-wider text-black bg-[#00f0ff] hover:bg-cyan-300 rounded-lg transition-all shadow-[0_0_25px_rgba(0,240,255,0.4)] hover:shadow-[0_0_35px_rgba(0,240,255,0.6)] cursor-pointer"
                >
                  <ShoppingBag className="w-4 h-4" />
                  <span>Explorer les Collections</span>
                </button>

                <button
                  onClick={() => onNavigate('contact')}
                  className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-4 text-sm font-semibold text-white bg-white/10 hover:bg-white/15 border border-white/15 rounded-lg transition-all cursor-pointer"
                >
                  <span>Demander un Devis / Contact</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>

              {/* Trust Indicators */}
              <div className="pt-6 border-t border-white/10 grid grid-cols-3 gap-4 text-left">
                <div>
                  <div className="text-xl sm:text-2xl font-black text-white font-display tabular-nums">100%</div>
                  <div className="text-xs text-neutral-400">Qualité inspectée & authentique</div>
                </div>
                <div>
                  <div className="text-xl sm:text-2xl font-black text-white font-display tabular-nums">24h</div>
                  <div className="text-xs text-neutral-400">Livraison rapide sur Abidjan</div>
                </div>
                <div>
                  <div className="text-xl sm:text-2xl font-black text-[#00f0ff] font-display tabular-nums">-35%</div>
                  <div className="text-xs text-neutral-400">Tarifs de gros pour revendeurs</div>
                </div>
              </div>
            </div>

            {/* Right Column: Hero High-Fashion Visual */}
            <div className="lg:col-span-5 relative">
              <div className="relative rounded-2xl overflow-hidden border border-white/15 shadow-2xl bg-neutral-900 group">
                <img
                  src="/src/assets/images/hero_streetwear_abidjan_1790967767459.jpg"
                  alt="Streetwear Lookbook SUPERSTAR_STR à Abidjan"
                  referrerPolicy="no-referrer"
                  className="w-full h-[450px] sm:h-[500px] object-cover object-center group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/30 to-transparent" />
                
                {/* Hero Overlay Card */}
                <div className="absolute bottom-6 left-6 right-6 p-4 rounded-xl bg-black/70 backdrop-blur-md border border-white/15 flex items-center justify-between">
                  <div>
                    <div className="text-xs uppercase tracking-widest text-[#00f0ff] font-bold">Arrivage Exclusif</div>
                    <div className="text-white font-semibold text-sm">Collection Streetwear 2026</div>
                    <div className="text-xs text-neutral-400">Disponibilité limitée · Abidjan 01</div>
                  </div>
                  <button
                    onClick={() => onNavigate('contact', 'Renseignement sur la Collection Streetwear 2026')}
                    className="p-2.5 rounded-lg bg-[#00f0ff] text-black hover:bg-cyan-300 transition-colors"
                    aria-label="Contacter pour la collection"
                  >
                    <ArrowUpRight className="w-5 h-5" />
                  </button>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>

      {/* 2. REASSURANCE & PILLARS OF EXCELLENCE */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 rounded-xl bg-[#0c0e14] border border-white/10 hover:border-cyan-500/30 transition-colors space-y-3">
            <div className="w-12 h-12 rounded-lg bg-cyan-500/10 border border-cyan-400/20 flex items-center justify-center text-[#00f0ff]">
              <Truck className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white font-display">
              Livraison Express Abidjan
            </h3>
            <p className="text-xs sm:text-sm text-neutral-400 leading-relaxed">
              Expédition le jour même ou sous 24h dans toutes les communes (Cocody, Marcory, Yopougon, Plateau...). Paiement sécurisé à la livraison disponible.
            </p>
          </div>

          <div className="p-6 rounded-xl bg-[#0c0e14] border border-white/10 hover:border-cyan-500/30 transition-colors space-y-3">
            <div className="w-12 h-12 rounded-lg bg-cyan-500/10 border border-cyan-400/20 flex items-center justify-center text-[#00f0ff]">
              <Store className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white font-display">
              Offres Petites Entreprises
            </h3>
            <p className="text-xs sm:text-sm text-neutral-400 leading-relaxed">
              Conditions de grossiste adaptées aux jeunes créateurs et gérants de boutiques. Packs de démarrage avec marge commerciale garantie.
            </p>
          </div>

          <div className="p-6 rounded-xl bg-[#0c0e14] border border-white/10 hover:border-cyan-500/30 transition-colors space-y-3">
            <div className="w-12 h-12 rounded-lg bg-cyan-500/10 border border-cyan-400/20 flex items-center justify-center text-[#00f0ff]">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <h3 className="text-lg font-bold text-white font-display">
              100% Qualité & Conformité
            </h3>
            <p className="text-xs sm:text-sm text-neutral-400 leading-relaxed">
              Chaque pièce (coutures, matières, finitions, pointures) est rigoureusement contrôlée avant livraison. Vous recevez exactement ce que vous voyez.
            </p>
          </div>
        </div>
      </section>

      {/* 3. CATALOGUE VITRINE AVEC BOUTON COMMANDE/CONTACT */}
      <section id="catalogue-section" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 scroll-mt-24">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10 pb-6 border-b border-white/10">
          <div>
            <div className="text-xs uppercase tracking-widest text-[#00f0ff] font-bold mb-2">
              Catalogue Sélectionné
            </div>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white font-display">
              Articles Phares & Arrivages
            </h2>
            <p className="text-sm text-neutral-400 mt-1 max-w-xl">
              Cliquez sur un article pour initier votre commande ou obtenir des détails instantanés via notre formulaire officiel.
            </p>
          </div>

          {/* Category Filter Tabs */}
          <div className="flex items-center gap-1.5 p-1 bg-white/5 border border-white/10 rounded-lg overflow-x-auto max-w-full">
            {[
              { id: 'all', label: 'Tous' },
              { id: 'vetements', label: 'Vêtements' },
              { id: 'chaussures', label: 'Sneakers' },
              { id: 'accessoires', label: 'Accessoires' },
              { id: 'packs-pro', label: 'Packs Pro' },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setSelectedCategory(tab.id as any)}
                className={`px-3 py-1.5 text-xs font-semibold rounded-md whitespace-nowrap transition-all cursor-pointer ${
                  selectedCategory === tab.id
                    ? 'bg-[#00f0ff] text-black shadow-sm'
                    : 'text-neutral-400 hover:text-white'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Product Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredProducts.map((product) => (
            <div
              key={product.id}
              className="bg-[#0c0e14] border border-white/10 rounded-xl overflow-hidden hover:border-cyan-500/40 transition-all duration-300 flex flex-col group shadow-lg"
            >
              {/* Image Area */}
              <div className="relative aspect-[4/3] bg-neutral-900 overflow-hidden">
                <img
                  src={product.image}
                  alt={product.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                
                {/* Category label / Tag */}
                <div className="absolute top-3 left-3">
                  <span className="text-[11px] font-semibold uppercase tracking-wider px-2.5 py-1 bg-black/75 backdrop-blur-sm border border-white/15 text-white rounded">
                    {product.categoryLabel}
                  </span>
                </div>

                {product.badge && (
                  <div className="absolute top-3 right-3">
                    <span className="text-[11px] font-bold uppercase tracking-wider px-2 py-0.5 bg-[#00f0ff] text-black rounded font-mono">
                      {product.badge}
                    </span>
                  </div>
                )}
              </div>

              {/* Content Area */}
              <div className="p-6 flex-1 flex flex-col justify-between space-y-4">
                <div>
                  <div className="flex items-baseline justify-between gap-2 mb-1.5">
                    <h3 className="text-lg font-bold text-white font-display leading-snug group-hover:text-cyan-300 transition-colors">
                      {product.name}
                    </h3>
                  </div>
                  <div className="text-xl font-extrabold text-[#00f0ff] font-display tabular-nums mb-2">
                    {product.price}
                  </div>
                  <p className="text-xs text-neutral-400 leading-relaxed line-clamp-2">
                    {product.description}
                  </p>
                </div>

                {/* Action CTA */}
                <button
                  onClick={() => handleOrderProduct(product)}
                  className="w-full py-2.5 px-4 rounded-lg bg-white/5 hover:bg-[#00f0ff] text-white hover:text-black font-semibold text-xs tracking-wider uppercase border border-white/15 hover:border-transparent transition-all flex items-center justify-center gap-2 cursor-pointer"
                >
                  <span>Commander via formulaire</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Banner for Custom Orders */}
        <div className="mt-12 p-8 rounded-xl bg-gradient-to-r from-blue-950/40 via-cyan-950/30 to-black border border-cyan-500/20 flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-1 text-center md:text-left">
            <h4 className="text-xl font-bold text-white font-display">
              Vous cherchez un modèle spécifique non affiché ?
            </h4>
            <p className="text-xs sm:text-sm text-neutral-400">
              Notre service de Sourcing Express à Abidjan trouve et fait venir vos pièces favorites sur commande.
            </p>
          </div>
          <button
            onClick={() => onNavigate('contact', 'Demande de recherche personnalisée (Sourcing)')}
            className="px-6 py-3 bg-[#00f0ff] hover:bg-cyan-300 text-black font-bold text-xs uppercase tracking-wider rounded-lg transition-colors whitespace-nowrap cursor-pointer shadow-md"
          >
            Demander une recherche personnalisée
          </button>
        </div>
      </section>

      {/* 4. DUAL TARGET AUDIENCE SHOWCASE (B2C & B2B) */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-14">
          <div className="text-xs uppercase tracking-widest text-[#00f0ff] font-bold mb-2">
            Notre Mission & Solutions
          </div>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-white font-display">
            Conçu pour la Jeunesse et les Petites Entreprises
          </h2>
          <p className="text-neutral-400 text-sm mt-3 leading-relaxed">
            SUPERSTAR_STR répond avec précision aux besoins des consommateurs particuliers passionnés de look et aux professionnels du textile en Côte d’Ivoire.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          
          {/* Box 1: Pour les Particuliers & Moins Âgés */}
          <div className="p-8 sm:p-10 rounded-2xl bg-[#0c0e14] border border-white/10 relative overflow-hidden flex flex-col justify-between group">
            <div className="space-y-6 relative z-10">
              <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-cyan-400">
                <Users className="w-4 h-4" />
                <span>Pour les Particuliers & Passionnés de Mode</span>
              </div>
              <h3 className="text-2xl sm:text-3xl font-bold text-white font-display">
                Exprimez votre style avec des pièces uniques
              </h3>
              <p className="text-sm text-neutral-300 leading-relaxed">
                Fini les tenues génériques. Accédez aux silhouettes streetwear qui font la tendance mondiale : t-shirts graphiques, pantalons cargos ajustés, vestes statement et baskets convoitées.
              </p>
              <ul className="space-y-3 text-xs sm:text-sm text-neutral-300">
                <li className="flex items-center gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-[#00f0ff] shrink-0" />
                  <span>Tailles et coupes idéales validées par nos conseillers</span>
                </li>
                <li className="flex items-center gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-[#00f0ff] shrink-0" />
                  <span>Livraison express à domicile ou sur votre lieu de travail</span>
                </li>
                <li className="flex items-center gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-[#00f0ff] shrink-0" />
                  <span>Échanges facilités en cas de doute sur la pointure</span>
                </li>
              </ul>
            </div>
            
            <div className="pt-8 mt-8 border-t border-white/10 relative z-10">
              <button
                onClick={() => onNavigate('contact', 'Demande particulier - Conseil de style / Commande')}
                className="w-full py-3 px-5 rounded-lg bg-white/10 hover:bg-white/15 text-white font-semibold text-xs uppercase tracking-wider transition-colors flex items-center justify-center gap-2"
              >
                <span>Contacter pour vos commandes perso</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Box 2: Pour les Petites Entreprises & Revendeurs */}
          <div className="p-8 sm:p-10 rounded-2xl bg-[#0c0e14] border border-cyan-500/30 relative overflow-hidden flex flex-col justify-between group shadow-[0_0_30px_rgba(0,240,255,0.06)]">
            <div className="space-y-6 relative z-10">
              <div className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#00f0ff]">
                <Store className="w-4 h-4" />
                <span>Pour les Petites Entreprises & Revendeurs</span>
              </div>
              <h3 className="text-2xl sm:text-3xl font-bold text-white font-display">
                Approvisionnez votre boutique avec forte rentabilité
              </h3>
              <p className="text-sm text-neutral-300 leading-relaxed">
                Vous gérez une boutique de quartier à Abidjan, un compte de vente en ligne ou une friperie chic ? Bénéficiez de lots de qualité supérieure à tarifs dégressifs.
              </p>
              <ul className="space-y-3 text-xs sm:text-sm text-neutral-300">
                <li className="flex items-center gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-[#00f0ff] shrink-0" />
                  <span>Packs dès 10 à 50 pièces sans investissement démesuré</span>
                </li>
                <li className="flex items-center gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-[#00f0ff] shrink-0" />
                  <span>Marges nettes constatées entre 30% et 60% par pièce</span>
                </li>
                <li className="flex items-center gap-2.5">
                  <CheckCircle2 className="w-4 h-4 text-[#00f0ff] shrink-0" />
                  <span>Livraison prioritaire et conseils sur les meilleures rotations</span>
                </li>
              </ul>
            </div>

            <div className="pt-8 mt-8 border-t border-white/10 relative z-10">
              <button
                onClick={() => onNavigate('contact', 'Demande Pack Petite Entreprise / Tarifs Revendeur')}
                className="w-full py-3 px-5 rounded-lg bg-[#00f0ff] hover:bg-cyan-300 text-black font-bold text-xs uppercase tracking-wider transition-all shadow-md flex items-center justify-center gap-2"
              >
                <span>Demander le tarif revendeur B2B</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

        </div>
      </section>

      {/* 5. TÉMOIGNAGES & PREUVE SOCIALE */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-10 text-center">
          <div className="text-xs uppercase tracking-widest text-[#00f0ff] font-bold mb-2">
            Preuve Sociale & Avis Clients
          </div>
          <h2 className="text-3xl font-extrabold text-white font-display">
            Ce que disent nos clients à Abidjan
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {TESTIMONIALS.map((t) => (
            <div
              key={t.id}
              className="p-6 rounded-xl bg-[#0c0e14] border border-white/10 flex flex-col justify-between space-y-4"
            >
              <p className="text-xs sm:text-sm text-neutral-300 italic leading-relaxed">
                "{t.comment}"
              </p>
              <div className="pt-4 border-t border-white/10 flex items-center justify-between text-xs">
                <div>
                  <div className="text-white font-bold">{t.author}</div>
                  <div className="text-neutral-400">{t.role} · {t.location}</div>
                </div>
                <div className="text-[11px] text-cyan-300 font-mono">
                  {t.item}
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* 6. CONVERSION CONTACT FORM ANCHOR */}
      <section id="contact-form-section" className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <ContactForm />
      </section>

    </div>
  );
};
