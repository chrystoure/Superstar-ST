import React, { useState } from 'react';
import { ContactForm } from '../components/ContactForm';
import { COMPANY_INFO } from '../data/catalog';
import { Phone, Mail, MapPin, Clock, MessageSquare, ChevronDown, ChevronUp, Sparkles, HelpCircle, ArrowUpRight } from 'lucide-react';

interface ContactPageProps {
  initialSubject?: string;
  initialMessage?: string;
}

export const ContactPage: React.FC<ContactPageProps> = ({
  initialSubject = '',
  initialMessage = '',
}) => {
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);

  const faqs = [
    {
      q: 'Quels sont les délais de livraison à Abidjan et à l’intérieur du pays ?',
      a: 'Pour les commandes livrées à Abidjan (Cocody, Marcory, Plateau, Yopougon, Koumassi, etc.), la livraison s’effectue le jour même ou sous 24h ouvrées. Pour les villes de l’intérieur de la Côte d’Ivoire (Bouaké, San-Pedro, Yamoussoukro, Korhogo...), comptez 24 à 48h via nos transporteurs partenaires sécurisés.',
    },
    {
      q: 'Peut-on payer à la livraison à Abidjan ?',
      a: 'Oui ! Pour toutes les livraisons effectuées à Abidjan, vous avez la possibilité de vérifier votre colis lors de la remise par le coursier et de régler en espèces ou par Mobile Money (Wave, Orange Money, MTN MoMo).',
    },
    {
      q: 'Comment fonctionnent les packs grossistes pour petites entreprises ?',
      a: 'Nos packs revendeurs sont conçus pour les petites boutiques et créateurs débutants. Vous pouvez composer votre assortiment dès 10 à 15 pièces (panachage de modèles et tailles autorisé). Remplissez le formulaire de contact en sélectionnant le profil "Petite Entreprise / Revendeur" pour recevoir notre grille tarifaire préférentielle.',
    },
    {
      q: 'Puis-je commander une pointure ou une paire de sneakers introuvable à Abidjan ?',
      a: 'Absolument. Grâce à notre service de Personal Sourcing, transmettez-nous la photo ou la référence exacte de la paire ou du vêtement de vos rêves dans le formulaire. Nous vous répondons avec un devis global incluant l’achat et l’acheminement direct à Abidjan.',
    },
    {
      q: 'Que faire si la taille ou la pointure ne me convient pas ?',
      a: 'Si la taille ne convient pas lors de l’essayage à la livraison, notre coursier peut vous proposer un échange direct selon les disponibilités en stock sous 24h. Nous veillons à ce que votre satisfaction soit totale.',
    },
  ];

  return (
    <div className="space-y-20 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      
      {/* 1. Header Contact */}
      <section className="text-center max-w-3xl mx-auto space-y-4">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 text-xs font-semibold text-cyan-300">
          <Sparkles className="w-3.5 h-3.5 text-[#00f0ff]" />
          <span>Contact Direct & Commandes</span>
        </div>

        <h1 className="text-4xl sm:text-5xl font-black text-white font-display tracking-tight text-balance">
          Contactez <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-cyan-200 to-[#00f0ff]">SUPERSTAR_STR</span> à Abidjan
        </h1>

        <p className="text-base text-neutral-300 leading-relaxed font-normal">
          Une question sur nos collections, une commande personnelle ou une demande de devis revendeur pour votre petite entreprise ? Écrivez-nous ou appelez-nous directement.
        </p>
      </section>

      {/* 2. Coordonnées Cards + Formulaire Grid */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
        
        {/* Left Column: Direct Coordinates & Hours */}
        <div className="lg:col-span-5 space-y-6">
          
          {/* Card 1: Coordonnées officielles */}
          <div className="p-6 sm:p-8 rounded-2xl bg-[#0c0e14] border border-white/10 space-y-6">
            <h3 className="text-xl font-bold text-white font-display">
              Nos Coordonnées Officielles
            </h3>

            <div className="space-y-5 text-sm">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-lg bg-cyan-500/10 border border-cyan-400/20 flex items-center justify-center text-[#00f0ff] shrink-0">
                  <Phone className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs uppercase tracking-wider text-neutral-400 font-medium">Téléphone & WhatsApp</div>
                  <a
                    href={`tel:${COMPANY_INFO.phone}`}
                    className="text-base font-bold text-white hover:text-cyan-300 transition-colors"
                  >
                    {COMPANY_INFO.phoneDisplay}
                  </a>
                  <p className="text-xs text-neutral-400 mt-0.5">Appels & messages 7j/7</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-lg bg-cyan-500/10 border border-cyan-400/20 flex items-center justify-center text-[#00f0ff] shrink-0">
                  <Mail className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs uppercase tracking-wider text-neutral-400 font-medium">Adresse Courriel</div>
                  <a
                    href={`mailto:${COMPANY_INFO.email}`}
                    className="text-base font-bold text-white hover:text-cyan-300 transition-colors break-all"
                  >
                    {COMPANY_INFO.email}
                  </a>
                  <p className="text-xs text-neutral-400 mt-0.5">Pour devis, factures & partenariats</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-lg bg-cyan-500/10 border border-cyan-400/20 flex items-center justify-center text-[#00f0ff] shrink-0">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs uppercase tracking-wider text-neutral-400 font-medium">Localisation & Siège</div>
                  <div className="text-base font-bold text-white">
                    {COMPANY_INFO.location}
                  </div>
                  <p className="text-xs text-neutral-400 mt-0.5">Distribution active sur toute l'agglomération</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-10 h-10 rounded-lg bg-cyan-500/10 border border-cyan-400/20 flex items-center justify-center text-[#00f0ff] shrink-0">
                  <Clock className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs uppercase tracking-wider text-neutral-400 font-medium">Disponibilité du service</div>
                  <div className="text-sm font-semibold text-white">
                    {COMPANY_INFO.openingHours}
                  </div>
                  <p className="text-xs text-neutral-400 mt-0.5">Réponse garantie sous 2 heures</p>
                </div>
              </div>
            </div>

            {/* Direct WhatsApp Callout */}
            <div className="pt-4 border-t border-white/10">
              <a
                href={COMPANY_INFO.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="w-full inline-flex items-center justify-center gap-2 py-3 px-4 bg-[#25D366] hover:bg-[#20ba5a] text-black font-bold text-xs uppercase tracking-wider rounded-lg transition-all shadow-md"
              >
                <MessageSquare className="w-4 h-4" />
                <span>Ouvrir WhatsApp (+225 07 12 10 51 80)</span>
                <ArrowUpRight className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Zones de livraison à Abidjan */}
          <div className="p-6 rounded-2xl bg-[#080a0e] border border-white/10 text-xs space-y-3">
            <h4 className="font-bold uppercase tracking-wider text-white flex items-center gap-2">
              <MapPin className="w-4 h-4 text-cyan-400" />
              <span>Communes desservies quotidiennement</span>
            </h4>
            <div className="flex flex-wrap gap-2 text-neutral-300">
              {[
                'Abidjan 01 (Plateau)',
                'Cocody Angré',
                'Cocody Deux-Plateaux',
                'Marcory Zone 4',
                'Marcory Biétry',
                'Yopougon',
                'Koumassi',
                'Treichville',
                'Riviera (1 à 6)',
                'Port-Bouët',
                'Bingerville',
                'Expédition Intérieur CI',
              ].map((zone, idx) => (
                <span
                  key={idx}
                  className="px-2.5 py-1 rounded bg-white/5 border border-white/10 text-[11px]"
                >
                  {zone}
                </span>
              ))}
            </div>
          </div>

        </div>

        {/* Right Column: High-Conversion Form */}
        <div className="lg:col-span-7">
          <ContactForm
            initialSubject={initialSubject}
            initialMessage={initialMessage}
          />
        </div>

      </section>

      {/* 3. Interactive FAQ Section */}
      <section className="max-w-4xl mx-auto pt-8">
        <div className="text-center mb-10">
          <div className="text-xs uppercase tracking-widest text-[#00f0ff] font-bold mb-2 flex items-center justify-center gap-1.5">
            <HelpCircle className="w-4 h-4" />
            <span>Foire Aux Questions</span>
          </div>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white font-display">
            Questions Fréquentes avant de commander
          </h2>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, index) => {
            const isOpen = openFaqIndex === index;

            return (
              <div
                key={index}
                className="rounded-xl border border-white/10 bg-[#0c0e14] overflow-hidden transition-colors"
              >
                <button
                  type="button"
                  onClick={() => setOpenFaqIndex(isOpen ? null : index)}
                  className="w-full p-5 text-left flex items-center justify-between gap-4 font-display font-bold text-sm sm:text-base text-white hover:text-cyan-300 transition-colors cursor-pointer"
                >
                  <span>{faq.q}</span>
                  {isOpen ? (
                    <ChevronUp className="w-5 h-5 text-cyan-400 shrink-0" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-neutral-400 shrink-0" />
                  )}
                </button>

                {isOpen && (
                  <div className="px-5 pb-5 pt-1 text-xs sm:text-sm text-neutral-300 leading-relaxed border-t border-white/5 animate-in fade-in duration-150">
                    {faq.a}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </section>

    </div>
  );
};
