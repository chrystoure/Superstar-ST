import React from 'react';
import { Shield, Sparkles, MapPin, Target, Eye, Award, CheckCircle2, ArrowRight } from 'lucide-react';
import { BrandLogo } from '../components/BrandLogo';
import { COMPANY_INFO } from '../data/catalog';
import { PageId } from '../components/Navbar';

interface AboutPageProps {
  onNavigate: (page: PageId, extraParam?: string) => void;
}

export const AboutPage: React.FC<AboutPageProps> = ({ onNavigate }) => {
  return (
    <div className="space-y-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      
      {/* 1. Header Hero À Propos */}
      <section className="text-center max-w-3xl mx-auto space-y-6">
        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-white/5 border border-white/10 text-xs font-semibold text-cyan-300">
          <Sparkles className="w-3.5 h-3.5 text-[#00f0ff]" />
          <span>Histoire & Identité de Marque</span>
        </div>

        <h1 className="text-4xl sm:text-5xl font-black text-white font-display tracking-tight text-balance">
          L'Énergie Streetwear & l’Excellence de la Mode à <span className="text-transparent bg-clip-text bg-gradient-to-r from-white via-cyan-200 to-[#00f0ff]">Abidjan</span>
        </h1>

        <p className="text-base sm:text-lg text-neutral-300 leading-relaxed font-normal">
          Fondée avec la volonté d’apporter une mode urbaine pointue, contemporaine et accessible à la jeunesse ivoirienne tout en créant une passerelle d'approvisionnement fiable pour les petites entreprises locales.
        </p>
      </section>

      {/* 2. Brand Visual & Story */}
      <section className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
        <div className="lg:col-span-6 relative">
          <div className="rounded-2xl overflow-hidden border border-white/15 bg-neutral-900 shadow-2xl group">
            <img
              src="/src/assets/images/about_fashion_studio_1790967812967.jpg"
              alt="Showroom et espace de sélection de mode SUPERSTAR_STR à Abidjan"
              referrerPolicy="no-referrer"
              className="w-full h-[420px] sm:h-[480px] object-cover object-center group-hover:scale-105 transition-transform duration-700"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/85 via-black/20 to-transparent" />
            <div className="absolute bottom-6 left-6 right-6 p-4 rounded-xl bg-black/75 backdrop-blur-md border border-white/15">
              <div className="text-xs uppercase tracking-widest text-[#00f0ff] font-bold">Showroom & Distribution</div>
              <div className="text-white font-semibold text-sm">Centre Logistique Abidjan 01</div>
              <div className="text-xs text-neutral-400">Côte d'Ivoire · Expéditions quotidiennes</div>
            </div>
          </div>
        </div>

        <div className="lg:col-span-6 space-y-6">
          <div className="text-xs uppercase tracking-widest text-[#00f0ff] font-bold">
            Notre Genèse
          </div>

          <h2 className="text-3xl sm:text-4xl font-extrabold text-white font-display">
            Une réponse concrète aux passionnés de style et aux créateurs
          </h2>

          <div className="space-y-4 text-sm text-neutral-300 leading-relaxed">
            <p>
              À Abidjan, la jeunesse bouillonne de créativité. Pourtant, accéder à des pièces de streetwear authentiques — baskets aux coupes avant-gardistes, vestes techniques, hoodies haut grammage — relevait souvent du parcours du combattant entre contrefaçons douteuses et délais d’attente interminables.
            </p>
            <p>
              C'est pour combler ce vide que <strong className="text-white">SUPERSTAR_STR</strong> a vu le jour. Nous sélectionnons rigoureusement chaque article auprès des meilleurs ateliers pour garantir des finitions irréprochables.
            </p>
            <p>
              Parallèlement, nous avons développé une offre dédiée aux <strong className="text-white">petites entreprises, boutiques de quartier et jeunes revendeurs</strong> d’Abidjan et de l’intérieur de la Côte d’Ivoire, leur permettant d'accéder à des tarifs dégressifs de gros sans exiger des capitaux astronomiques.
            </p>
          </div>

          <div className="pt-4 flex flex-col sm:flex-row items-center gap-4">
            <button
              onClick={() => onNavigate('contact', 'Demande de renseignement suite à la page À propos')}
              className="w-full sm:w-auto px-6 py-3.5 bg-[#00f0ff] hover:bg-cyan-300 text-black font-bold text-xs uppercase tracking-wider rounded-lg transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer"
            >
              <span>Prendre contact avec nous</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={() => onNavigate('services')}
              className="w-full sm:w-auto px-6 py-3.5 bg-white/5 hover:bg-white/10 text-white font-medium text-xs uppercase tracking-wider border border-white/10 rounded-lg transition-colors cursor-pointer"
            >
              Découvrir nos services
            </button>
          </div>
        </div>
      </section>

      {/* 3. Nos 3 Piliers Fondamentaux */}
      <section className="space-y-12">
        <div className="text-center max-w-2xl mx-auto">
          <div className="text-xs uppercase tracking-widest text-[#00f0ff] font-bold mb-2">
            Ce Qui Nous Définit
          </div>
          <h2 className="text-3xl font-extrabold text-white font-display">
            Nos Valeurs & Engagements
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="p-8 rounded-xl bg-[#0c0e14] border border-white/10 space-y-4">
            <div className="w-12 h-12 rounded-lg bg-cyan-500/10 border border-cyan-400/20 flex items-center justify-center text-[#00f0ff]">
              <Award className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold text-white font-display">
              Authenticité & Qualité Stricte
            </h3>
            <p className="text-xs sm:text-sm text-neutral-400 leading-relaxed">
              Pas de mauvaise surprise. Chaque paire de sneakers et chaque vêtement fait l'objet d'un contrôle visuel et tactile minutieux avant mise en vente ou expédition à nos clients.
            </p>
          </div>

          <div className="p-8 rounded-xl bg-[#0c0e14] border border-white/10 space-y-4">
            <div className="w-12 h-12 rounded-lg bg-cyan-500/10 border border-cyan-400/20 flex items-center justify-center text-[#00f0ff]">
              <Target className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold text-white font-display">
              Soutien aux Jeunes Entrepreneurs
            </h3>
            <p className="text-xs sm:text-sm text-neutral-400 leading-relaxed">
              Nous croyons au génie entrepreneurial de la jeunesse ivoirienne. Nos packs revendeurs permettent aux étudiants et jeunes commerçants de lancer leur activité mode avec une vraie marge.
            </p>
          </div>

          <div className="p-8 rounded-xl bg-[#0c0e14] border border-white/10 space-y-4">
            <div className="w-12 h-12 rounded-lg bg-cyan-500/10 border border-cyan-400/20 flex items-center justify-center text-[#00f0ff]">
              <MapPin className="w-6 h-6" />
            </div>
            <h3 className="text-xl font-bold text-white font-display">
              Ancrage Local & Réactivité Abidjan
            </h3>
            <p className="text-xs sm:text-sm text-neutral-400 leading-relaxed">
              Basés à Abidjan 01, nous maîtrisons les réalités logistiques de la métropole. Livraisons en main propre rapides et assistance directe via WhatsApp.
            </p>
          </div>
        </div>
      </section>

      {/* 4. Emblème & Signature */}
      <section className="p-8 sm:p-12 rounded-2xl bg-gradient-to-b from-[#0e121a] to-black border border-white/10 text-center space-y-6">
        <BrandLogo variant="compact" />
        <h3 className="text-2xl font-bold text-white font-display">
          SUPERSTAR_STR · La Marque du Futur Urbain
        </h3>
        <p className="text-neutral-400 text-sm max-w-xl mx-auto leading-relaxed">
          Rejoignez la communauté de ceux qui osent afficher leur singularité. Pour toute commande spéciale ou partenariat revendeur, nos équipes sont à votre entière disposition.
        </p>
        <div className="pt-2">
          <button
            onClick={() => onNavigate('contact')}
            className="px-8 py-3.5 bg-[#00f0ff] hover:bg-cyan-300 text-black font-bold text-xs uppercase tracking-wider rounded-lg transition-all shadow-[0_0_20px_rgba(0,240,255,0.3)] cursor-pointer"
          >
            Nous contacter maintenant
          </button>
        </div>
      </section>

    </div>
  );
};
