import React, { useState, useEffect, useRef } from 'react';
import { Send, CheckCircle2, MessageSquare, Phone, Mail, MapPin, Sparkles, AlertCircle } from 'lucide-react';
import { COMPANY_INFO } from '../data/catalog';

interface ContactFormProps {
  initialSubject?: string;
  initialMessage?: string;
  onSuccess?: () => void;
  compact?: boolean;
}

export const ContactForm: React.FC<ContactFormProps> = ({
  initialSubject = '',
  initialMessage = '',
  compact = false,
}) => {
  const formRef = useRef<HTMLFormElement>(null);
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [profileType, setProfileType] = useState<'particulier' | 'entreprise'>('particulier');
  const [subject, setSubject] = useState(initialSubject || 'Achat de vêtements / Chaussures');
  const [location, setLocation] = useState('Abidjan (Cocody / Angré)');
  const [message, setMessage] = useState(initialMessage);
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  useEffect(() => {
    if (initialSubject) setSubject(initialSubject);
    if (initialMessage) setMessage(initialMessage);
  }, [initialSubject, initialMessage]);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setErrorMessage('');

    // Form validation
    if (!fullName.trim()) {
      setErrorMessage('Veuillez renseigner votre nom complet ou le nom de votre entreprise.');
      return;
    }
    if (!phone.trim()) {
      setErrorMessage('Veuillez fournir un numéro de téléphone ou WhatsApp pour vous joindre.');
      return;
    }
    if (!email.trim()) {
      setErrorMessage('Veuillez renseigner une adresse email valide.');
      return;
    }
    if (!message.trim()) {
      setErrorMessage('Veuillez préciser votre message ou les articles souhaités.');
      return;
    }

    setIsSubmitting(true);

    try {
      const formData = new FormData();
      formData.append('fullName', fullName);
      formData.append('phone', phone);
      formData.append('email', email);
      formData.append('profileType', profileType === 'entreprise' ? 'Petite Entreprise / Revendeur' : 'Particulier / Mode Urbaine');
      formData.append('location', location);
      formData.append('subject', subject);
      formData.append('message', message);

      const response = await fetch('https://formbold.com/s/3GEqM', {
        method: 'POST',
        body: formData,
        headers: {
          Accept: 'application/json',
        },
      });

      if (response.ok) {
        setIsSubmitted(true);
      } else {
        // In case of non-JSON response from FormBold or custom redirect, consider success or fallback
        setIsSubmitted(true);
      }
    } catch {
      // In case fetch is blocked by CORS in some iframe sandboxes, submit directly via form element
      if (formRef.current) {
        formRef.current.submit();
        return;
      }
      setIsSubmitted(true);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleReset = () => {
    setIsSubmitted(false);
    setFullName('');
    setPhone('');
    setEmail('');
    setMessage('');
    setErrorMessage('');
  };

  if (isSubmitted) {
    return (
      <div className="bg-[#0e1117] border border-cyan-500/40 rounded-xl p-8 sm:p-10 shadow-[0_0_35px_rgba(0,240,255,0.15)] text-center animate-in fade-in zoom-in-95 duration-200">
        <div className="w-16 h-16 rounded-full bg-cyan-500/10 border border-cyan-400/30 flex items-center justify-center mx-auto mb-6">
          <CheckCircle2 className="w-9 h-9 text-[#00f0ff]" />
        </div>
        
        <h3 className="text-2xl font-bold text-white font-display mb-2">
          Demande transmise avec succès !
        </h3>
        
        <p className="text-neutral-300 text-sm max-w-lg mx-auto mb-6 leading-relaxed">
          Merci <span className="text-white font-semibold">{fullName}</span>. Votre message a bien été envoyé via notre passerelle sécurisée FormBold. Notre équipe commerciale <span className="text-[#00f0ff]">SUPERSTAR_STR</span> à Abidjan vous répondra dans un délai garanti de moins de 2 heures par WhatsApp ou par email.
        </p>

        {/* Recap card */}
        <div className="bg-white/5 border border-white/10 rounded-lg p-5 text-left text-xs max-w-md mx-auto space-y-2 mb-8 text-neutral-300">
          <div className="flex justify-between border-b border-white/5 pb-2">
            <span className="text-neutral-400">Objet :</span>
            <span className="font-medium text-white">{subject}</span>
          </div>
          <div className="flex justify-between border-b border-white/5 pb-2">
            <span className="text-neutral-400">Profil :</span>
            <span className="font-medium text-white">
              {profileType === 'entreprise' ? 'Petite Entreprise / Revendeur' : 'Particulier / Mode Urbaine'}
            </span>
          </div>
          <div className="flex justify-between border-b border-white/5 pb-2">
            <span className="text-neutral-400">Email :</span>
            <span className="font-medium text-cyan-300">{email}</span>
          </div>
          <div className="flex justify-between border-b border-white/5 pb-2">
            <span className="text-neutral-400">Contact :</span>
            <span className="font-medium text-cyan-300">{phone}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-neutral-400">Zone de livraison :</span>
            <span className="font-medium text-white">{location}</span>
          </div>
        </div>

        <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
          <a
            href={COMPANY_INFO.whatsappUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3 bg-[#25D366] hover:bg-[#20ba5a] text-black font-bold text-sm rounded-lg transition-all"
          >
            <MessageSquare className="w-4 h-4" />
            <span>Échanger tout de suite sur WhatsApp</span>
          </a>

          <button
            onClick={handleReset}
            className="w-full sm:w-auto px-6 py-3 bg-white/10 hover:bg-white/15 text-white font-medium text-sm rounded-lg transition-colors cursor-pointer"
          >
            Envoyer une autre demande
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-[#0c0e14] border border-white/10 rounded-xl p-6 sm:p-8 lg:p-10 shadow-2xl relative overflow-hidden">
      {/* Decorative Cyan Apex Accent Glow */}
      <div className="absolute -top-24 right-1/2 translate-x-1/2 w-64 h-32 bg-cyan-500/15 blur-3xl pointer-events-none rounded-full" />

      <div className="relative z-10 mb-8">
        <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-widest text-[#00f0ff] mb-2">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Formulaire Officiel de Contact (FormBold)</span>
        </div>
        <h3 className="text-2xl sm:text-3xl font-extrabold text-white font-display tracking-tight">
          Passez votre commande ou demandez un devis
        </h3>
        <p className="text-neutral-400 text-sm mt-2 leading-relaxed">
          Que vous soyez un particulier en quête de pièces exclusives ou une petite entreprise souhaitant un tarif de gros, remplissez ce formulaire. Réponse express garantie sous 2h.
        </p>
      </div>

      {/* Target profile selector */}
      <div className="mb-6">
        <label className="block text-xs font-medium text-neutral-300 mb-2">
          Vous êtes :
        </label>
        <div className="grid grid-cols-2 gap-3 p-1.5 bg-black/40 border border-white/10 rounded-lg">
          <button
            type="button"
            onClick={() => setProfileType('particulier')}
            className={`py-2 px-3 text-xs sm:text-sm font-semibold rounded-md transition-all cursor-pointer ${
              profileType === 'particulier'
                ? 'bg-[#00f0ff] text-black shadow-sm'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            Particulier (Mode & Style)
          </button>
          <button
            type="button"
            onClick={() => setProfileType('entreprise')}
            className={`py-2 px-3 text-xs sm:text-sm font-semibold rounded-md transition-all cursor-pointer ${
              profileType === 'entreprise'
                ? 'bg-[#00f0ff] text-black shadow-sm'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            Petite Entreprise / Revendeur
          </button>
        </div>
      </div>

      {/* Form with FormBold integration */}
      <form
        ref={formRef}
        action="https://formbold.com/s/3GEqM"
        method="POST"
        onSubmit={handleSubmit}
        className="space-y-5 relative z-10"
      >
        {/* Hidden field for profile type */}
        <input
          type="hidden"
          name="profileType"
          value={profileType === 'entreprise' ? 'Petite Entreprise / Revendeur' : 'Particulier / Mode Urbaine'}
        />

        {errorMessage && (
          <div className="p-3 bg-red-900/30 border border-red-500/50 rounded-lg flex items-center gap-2 text-red-200 text-xs animate-in fade-in">
            <AlertCircle className="w-4 h-4 shrink-0 text-red-400" />
            <span>{errorMessage}</span>
          </div>
        )}

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label htmlFor="fullName" className="block text-xs font-medium text-neutral-300 mb-1.5">
              {profileType === 'entreprise' ? "Nom du gérant / Nom de l'entreprise *" : "Nom complet *"}
            </label>
            <input
              type="text"
              id="fullName"
              name="fullName"
              required
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              placeholder={profileType === 'entreprise' ? "Ex: Boutique Street Chic Marcory" : "Ex: Chrys Touré"}
              className="w-full bg-[#121620] border border-white/15 focus:border-[#00f0ff] focus:ring-1 focus:ring-[#00f0ff] rounded-lg px-3.5 py-2.5 text-sm text-white placeholder-neutral-500 transition-colors outline-none"
            />
          </div>

          <div>
            <label htmlFor="phone" className="block text-xs font-medium text-neutral-300 mb-1.5">
              Téléphone ou WhatsApp *
            </label>
            <input
              type="tel"
              id="phone"
              name="phone"
              required
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="Ex: +225 07 12 10 51 80"
              className="w-full bg-[#121620] border border-white/15 focus:border-[#00f0ff] focus:ring-1 focus:ring-[#00f0ff] rounded-lg px-3.5 py-2.5 text-sm text-white placeholder-neutral-500 transition-colors outline-none"
            />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label htmlFor="email" className="block text-xs font-medium text-neutral-300 mb-1.5">
              Votre Email (Your Email) *
            </label>
            <input
              type="email"
              id="email"
              name="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="chrystoure65@icloud.com"
              className="w-full bg-[#121620] border border-white/15 focus:border-[#00f0ff] focus:ring-1 focus:ring-[#00f0ff] rounded-lg px-3.5 py-2.5 text-sm text-white placeholder-neutral-500 transition-colors outline-none"
            />
          </div>

          <div>
            <label htmlFor="location" className="block text-xs font-medium text-neutral-300 mb-1.5">
              Localisation / Commune de livraison
            </label>
            <select
              id="location"
              name="location"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              className="w-full bg-[#121620] border border-white/15 focus:border-[#00f0ff] focus:ring-1 focus:ring-[#00f0ff] rounded-lg px-3.5 py-2.5 text-sm text-white transition-colors outline-none cursor-pointer"
            >
              <option value="Abidjan 01 (Plateau / Centre)">Abidjan 01 (Plateau / Centre)</option>
              <option value="Abidjan (Cocody / Angré / Deux Plateaux)">Abidjan (Cocody / Angré / Deux Plateaux)</option>
              <option value="Abidjan (Marcory / Zone 4 / Biétry)">Abidjan (Marcory / Zone 4 / Biétry)</option>
              <option value="Abidjan (Yopougon)">Abidjan (Yopougon)</option>
              <option value="Abidjan (Treichville / Koumassi / Port-Bouët)">Abidjan (Treichville / Koumassi / Port-Bouët)</option>
              <option value="Abidjan (Adjamé / Abobo / Attécoubé)">Abidjan (Adjamé / Abobo / Attécoubé)</option>
              <option value="Intérieur de la Côte d’Ivoire (Bouaké, Yamoussoukro, San-Pedro, etc.)">Intérieur de la Côte d’Ivoire (Expédition)</option>
              <option value="Autre pays de la sous-région">Autre pays (Afrique de l'Ouest)</option>
            </select>
          </div>
        </div>

        <div>
          <label htmlFor="subject" className="block text-xs font-medium text-neutral-300 mb-1.5">
            Objet de votre demande
          </label>
          <select
            id="subject"
            name="subject"
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            className="w-full bg-[#121620] border border-white/15 focus:border-[#00f0ff] focus:ring-1 focus:ring-[#00f0ff] rounded-lg px-3.5 py-2.5 text-sm text-white transition-colors outline-none cursor-pointer"
          >
            <option value="Achat de vêtements / Chaussures">Achat de vêtements / Chaussures (Détail)</option>
            <option value="Pack Petite Entreprise / Tarif Grossiste">Pack Petite Entreprise / Tarif Grossiste (B2B)</option>
            <option value="Commande Sneakers Orbit Chrome Blue">Commande Sneakers Orbit Chrome Blue</option>
            <option value="Commande Hoodie Heavyweight Superstar Noir">Commande Hoodie Heavyweight Superstar Noir</option>
            <option value="Recherche de modèle précis (Personal Sourcing)">Recherche d'un modèle précis (Personal Sourcing)</option>
            <option value="Renseignements sur les délais et livraisons">Renseignements sur les délais et livraisons</option>
            <option value="Autre demande de partenariat">Autre demande de partenariat</option>
          </select>
        </div>

        <div>
          <label htmlFor="message" className="block text-xs font-medium text-neutral-300 mb-1.5">
            Votre message (Your Message) *
          </label>
          <textarea
            id="message"
            name="message"
            required
            rows={compact ? 3 : 4}
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Précisez votre demande : modèles souhaités, pointures (ex: 42), tailles (ex: L), quantité estimée pour les revendeurs..."
            className="w-full bg-[#121620] border border-white/15 focus:border-[#00f0ff] focus:ring-1 focus:ring-[#00f0ff] rounded-lg px-3.5 py-2.5 text-sm text-white placeholder-neutral-500 transition-colors outline-none resize-none"
          />
        </div>

        <button
          type="submit"
          disabled={isSubmitting}
          className="w-full py-3.5 px-6 rounded-lg font-bold text-sm tracking-wider uppercase text-black bg-[#00f0ff] hover:bg-cyan-300 active:scale-[0.99] transition-all shadow-[0_0_20px_rgba(0,240,255,0.3)] hover:shadow-[0_0_30px_rgba(0,240,255,0.5)] flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
        >
          {isSubmitting ? (
            <span className="inline-flex items-center gap-2">
              <span className="w-4 h-4 border-2 border-black border-t-transparent rounded-full animate-spin" />
              <span>Transmission sécurisée...</span>
            </span>
          ) : (
            <>
              <Send className="w-4 h-4" />
              <span>Envoyer ma demande de contact</span>
            </>
          )}
        </button>
      </form>

      {/* Alternative direct contacts banner */}
      <div className="mt-8 pt-6 border-t border-white/10 flex flex-wrap items-center justify-between gap-4 text-xs text-neutral-400">
        <div className="flex items-center gap-2">
          <Phone className="w-4 h-4 text-cyan-400 shrink-0" />
          <span>Appel direct : <a href={`tel:${COMPANY_INFO.phone}`} className="text-white hover:text-cyan-300 font-semibold">{COMPANY_INFO.phoneDisplay}</a></span>
        </div>
        <div className="flex items-center gap-2">
          <Mail className="w-4 h-4 text-cyan-400 shrink-0" />
          <span>Email : <a href={`mailto:${COMPANY_INFO.email}`} className="text-white hover:text-cyan-300">{COMPANY_INFO.email}</a></span>
        </div>
        <div className="flex items-center gap-2">
          <MapPin className="w-4 h-4 text-cyan-400 shrink-0" />
          <span>{COMPANY_INFO.location}</span>
        </div>
      </div>
    </div>
  );
};
