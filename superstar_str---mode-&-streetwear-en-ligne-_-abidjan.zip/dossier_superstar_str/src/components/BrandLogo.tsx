import React from 'react';

interface BrandLogoProps {
  className?: string;
  variant?: 'full' | 'compact' | 'horizontal';
  showTagline?: boolean;
}

export const BrandLogo: React.FC<BrandLogoProps> = ({
  className = '',
  variant = 'horizontal',
  showTagline = false,
}) => {
  if (variant === 'compact') {
    return (
      <div className={`inline-flex items-center gap-2 ${className}`}>
        {/* Compact Atom Symbol + Blue Apex */}
        <div className="relative w-8 h-8 flex items-center justify-center">
          <div className="absolute inset-0 bg-cyan-500/20 blur-md rounded-full" />
          <svg viewBox="0 0 100 100" className="w-full h-full relative z-10" fill="none">
            {/* Triangular glow beacon */}
            <polygon points="50,12 85,45 15,45" fill="url(#compactBlueGrad)" opacity="0.85" />
            <ellipse cx="50" cy="62" rx="36" ry="14" stroke="#e2e8f0" strokeWidth="2.5" />
            <ellipse cx="50" cy="62" rx="36" ry="14" stroke="#e2e8f0" strokeWidth="2.5" transform="rotate(60 50 62)" />
            <ellipse cx="50" cy="62" rx="36" ry="14" stroke="#e2e8f0" strokeWidth="2.5" transform="rotate(-60 50 62)" />
            <circle cx="50" cy="62" r="6" fill="url(#silverSphere)" />
            <defs>
              <linearGradient id="compactBlueGrad" x1="50" y1="12" x2="50" y2="45" gradientUnits="userSpaceOnUse">
                <stop stopColor="#00f0ff" />
                <stop offset="0.6" stopColor="#0066ff" stopOpacity="0.8" />
                <stop offset="1" stopColor="#002266" stopOpacity="0" />
              </linearGradient>
              <radialGradient id="silverSphere" cx="40%" cy="40%" r="60%">
                <stop stopColor="#ffffff" />
                <stop offset="0.7" stopColor="#cbd5e1" />
                <stop offset="1" stopColor="#64748b" />
              </radialGradient>
            </defs>
          </svg>
        </div>
        <span className="font-extrabold tracking-wider text-white text-base font-display">
          SUPERSTAR<span className="text-[#00f0ff]">_STR</span>
        </span>
      </div>
    );
  }

  if (variant === 'full') {
    return (
      <div className={`relative flex flex-col items-center justify-center select-none ${className}`}>
        {/* Atmospheric Blue Light Glow */}
        <div className="absolute top-0 w-72 h-36 bg-cyan-400/25 blur-3xl rounded-full pointer-events-none" />

        <svg viewBox="0 0 500 320" className="w-full max-w-[460px] h-auto overflow-visible relative z-10">
          <defs>
            {/* Blue triangular beam gradient */}
            <linearGradient id="beaconGlow" x1="250" y1="20" x2="250" y2="120" gradientUnits="userSpaceOnUse">
              <stop offset="0%" stopColor="#00f0ff" stopOpacity="1" />
              <stop offset="40%" stopColor="#0077ff" stopOpacity="0.85" />
              <stop offset="100%" stopColor="#002b80" stopOpacity="0" />
            </linearGradient>

            {/* Light beam streaks */}
            <linearGradient id="rayGrad" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#00f0ff" stopOpacity="0.9" />
              <stop offset="100%" stopColor="#0066ff" stopOpacity="0" />
            </linearGradient>

            {/* Chrome metallic gradient for text */}
            <linearGradient id="chromeText" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#ffffff" />
              <stop offset="35%" stopColor="#e2e8f0" />
              <stop offset="55%" stopColor="#cbd5e1" />
              <stop offset="85%" stopColor="#94a3b8" />
              <stop offset="100%" stopColor="#64748b" />
            </linearGradient>

            {/* Nucleus metallic sphere */}
            <radialGradient id="atomicNucleus" cx="35%" cy="35%" r="65%">
              <stop offset="0%" stopColor="#ffffff" />
              <stop offset="45%" stopColor="#e2e8f0" />
              <stop offset="80%" stopColor="#94a3b8" />
              <stop offset="100%" stopColor="#475569" />
            </radialGradient>

            {/* Soft drop shadow */}
            <filter id="glowFilter" x="-20%" y="-20%" width="140%" height="140%">
              <feGaussianBlur stdDeviation="6" result="blur" />
              <feComposite in="SourceGraphic" in2="blur" operator="over" />
            </filter>
          </defs>

          {/* 1. Glowing Laser Triangle Peak */}
          <g>
            <polygon points="250,25 390,115 110,115" fill="url(#beaconGlow)" />
            {/* Luminous laser rays */}
            <line x1="250" y1="25" x2="190" y2="110" stroke="#00f0ff" strokeWidth="1.5" opacity="0.6" />
            <line x1="250" y1="25" x2="220" y2="110" stroke="#7dd3fc" strokeWidth="2" opacity="0.8" />
            <line x1="250" y1="25" x2="250" y2="110" stroke="#ffffff" strokeWidth="2.5" opacity="0.9" />
            <line x1="250" y1="25" x2="280" y2="110" stroke="#7dd3fc" strokeWidth="2" opacity="0.8" />
            <line x1="250" y1="25" x2="310" y2="110" stroke="#00f0ff" strokeWidth="1.5" opacity="0.6" />
            {/* Apex flare */}
            <circle cx="250" cy="25" r="4" fill="#ffffff" filter="url(#glowFilter)" />
          </g>

          {/* 2. Arched Futuristic Chrome Wordmark "SUPERSTAR" */}
          <g transform="translate(0, 15)">
            <text
              x="250"
              y="145"
              textAnchor="middle"
              className="font-extrabold uppercase font-display"
              style={{
                fontSize: '66px',
                fontWeight: 900,
                letterSpacing: '0.08em',
                fill: 'url(#chromeText)',
                stroke: '#ffffff',
                strokeWidth: '1.2px',
                filter: 'drop-shadow(0 4px 14px rgba(0,0,0,0.85))',
              }}
            >
              SUPERSTAR
            </text>
            <text
              x="395"
              y="120"
              className="font-bold uppercase font-display text-xs"
              style={{
                fontSize: '14px',
                fill: '#00f0ff',
                letterSpacing: '0.15em',
              }}
            >
              _STR
            </text>
          </g>

          {/* 3. Atomic Orbital Symbol */}
          <g transform="translate(250, 225)">
            {/* Orbital ring 1: Horizontal */}
            <ellipse cx="0" cy="0" rx="80" ry="26" stroke="#e2e8f0" strokeWidth="2.4" fill="none" opacity="0.85" />
            {/* Orbital ring 2: Rotated 60deg */}
            <ellipse cx="0" cy="0" rx="80" ry="26" stroke="#e2e8f0" strokeWidth="2.4" fill="none" opacity="0.85" transform="rotate(60)" />
            {/* Orbital ring 3: Rotated -60deg */}
            <ellipse cx="0" cy="0" rx="80" ry="26" stroke="#e2e8f0" strokeWidth="2.4" fill="none" opacity="0.85" transform="rotate(-60)" />
            {/* Central metallic nucleus */}
            <circle cx="0" cy="0" r="14" fill="url(#atomicNucleus)" stroke="#f8fafc" strokeWidth="1.5" />
            <circle cx="-3" cy="-4" r="3" fill="#ffffff" opacity="0.8" />
          </g>

          {/* Signature tag CRYS.T_5 */}
          <text x="440" y="275" textAnchor="end" className="text-[11px] font-mono tracking-widest fill-slate-400">
            CRYS.T_5
          </text>
        </svg>

        {showTagline && (
          <p className="text-xs uppercase tracking-[0.25em] text-cyan-300/80 font-medium text-center mt-1">
            Mode Urbaine & Streetwear · Abidjan
          </p>
        )}
      </div>
    );
  }

  // Horizontal variant (Ideal for headers)
  return (
    <div className={`inline-flex items-center gap-3 ${className}`}>
      {/* Mini atomic emblem */}
      <div className="relative w-9 h-9 flex items-center justify-center shrink-0">
        <div className="absolute inset-0 bg-[#00f0ff]/20 blur-md rounded-full" />
        <svg viewBox="0 0 100 100" className="w-full h-full relative z-10" fill="none">
          <polygon points="50,10 82,42 18,42" fill="url(#hBlueGrad)" opacity="0.9" />
          <ellipse cx="50" cy="62" rx="34" ry="13" stroke="#f1f5f9" strokeWidth="2.2" />
          <ellipse cx="50" cy="62" rx="34" ry="13" stroke="#f1f5f9" strokeWidth="2.2" transform="rotate(60 50 62)" />
          <ellipse cx="50" cy="62" rx="34" ry="13" stroke="#f1f5f9" strokeWidth="2.2" transform="rotate(-60 50 62)" />
          <circle cx="50" cy="62" r="6" fill="#e2e8f0" />
          <defs>
            <linearGradient id="hBlueGrad" x1="50" y1="10" x2="50" y2="42" gradientUnits="userSpaceOnUse">
              <stop stopColor="#00f0ff" />
              <stop offset="1" stopColor="#0055ff" stopOpacity="0.2" />
            </linearGradient>
          </defs>
        </svg>
      </div>

      <div className="flex flex-col">
        <span className="text-lg md:text-xl font-black tracking-tight text-white font-display leading-tight flex items-center gap-1">
          SUPERSTAR<span className="text-[#00f0ff] font-semibold">_STR</span>
        </span>
        {showTagline && (
          <span className="text-[10px] uppercase tracking-wider text-slate-400 font-medium -mt-0.5">
            Abidjan · Mode & Streetwear
          </span>
        )}
      </div>
    </div>
  );
};
