import React from 'react';
import { BrandLogo } from './BrandLogo';
import { COMPANY_INFO } from '../data/catalog';
import { Phone, Mail, MapPin, Clock, ArrowUpRight } from 'lucide-react';
import { PageId } from './Navbar';

interface FooterProps {
  onNavigate: (page: PageId) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const handleNav = (page: PageId) => {
    onNavigate(page);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-[#050608] border-t border-white/10 text-neutral-400 text-sm mt-20 relative overflow-hidden">
      {/* Subtle bottom glow */}
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-96 h-28 bg-cyan-600/10 blur-3xl pointer-events-none rounded-full" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14 relative z-10">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 mb-12">
          
          {/* Column 1: Brand & Identity */}
          <div className="space-y-4">
            <BrandLogo variant="horizontal" />
            <p className="text-xs text-neutral-400 leading-relaxed max-w-sm">
              Boutique de vente en ligne de référence à Abidjan pour les vêtements streetwear, sneakers d’exception et accessoires de mode. Conçu pour inspirer la jeunesse et propulser les petites entreprises de mode.
            </p>
            <div className="text-xs text-neutral-400 flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
              <span>Service commercial actif · Commandes 7j/7</span>
            </div>
          </div>

          {/* Column 2: Navigation Rapide */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-4">
              Navigation
            </h4>
            <ul className="space-y-2.5 text-xs">
              <li>
                <button
                  onClick={() => handleNav('accueil')}
                  className="hover:text-cyan-300 transition-colors flex items-center gap-1.5"
                >
                  <span>Accueil</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNav('apropos')}
                  className="hover:text-cyan-300 transition-colors flex items-center gap-1.5"
                >
                  <span>À propos & Vision</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNav('services')}
                  className="hover:text-cyan-300 transition-colors flex items-center gap-1.5"
                >
                  <span>Services & Packs Pro</span>
                </button>
              </li>
              <li>
                <button
                  onClick={() => handleNav('contact')}
                  className="hover:text-cyan-300 transition-colors flex items-center gap-1.5"
                >
                  <span>Contact & Devis</span>
                </button>
              </li>
            </ul>
          </div>

          {/* Column 3: Coordonnées Officielles */}
          <div>
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-4">
              Coordonnées Officielles
            </h4>
            <ul className="space-y-3 text-xs">
              <li className="flex items-start gap-2.5">
                <Phone className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                <div>
                  <div className="text-white font-medium">Téléphone & WhatsApp</div>
                  <a href={`tel:${COMPANY_INFO.phone}`} className="hover:text-cyan-300 transition-colors">
                    {COMPANY_INFO.phoneDisplay}
                  </a>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <Mail className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                <div>
                  <div className="text-white font-medium">Courriel professionnel</div>
                  <a href={`mailto:${COMPANY_INFO.email}`} className="hover:text-cyan-300 transition-colors">
                    {COMPANY_INFO.email}
                  </a>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                <div>
                  <div className="text-white font-medium">Siège & Distribution</div>
                  <span>{COMPANY_INFO.location}</span>
                </div>
              </li>
              <li className="flex items-start gap-2.5">
                <Clock className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                <div>
                  <div className="text-white font-medium">Horaires</div>
                  <span>{COMPANY_INFO.openingHours}</span>
                </div>
              </li>
            </ul>
          </div>

          {/* Column 4: Contact Express */}
          <div className="space-y-4">
            <h4 className="text-xs font-bold uppercase tracking-wider text-white mb-4">
              Contact Immédiat
            </h4>
            <p className="text-xs text-neutral-400 leading-relaxed">
              Une question sur une taille, un arrivage ou un pack revendeur ? Discutez directement avec notre équipe.
            </p>
            <a
              href={COMPANY_INFO.whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center justify-center gap-2 w-full py-2.5 px-4 bg-[#25D366] hover:bg-[#20ba5a] text-black font-bold text-xs rounded-lg transition-all"
            >
              <span>WhatsApp Direct</span>
              <ArrowUpRight className="w-3.5 h-3.5" />
            </a>
            <button
              onClick={() => handleNav('contact')}
              className="w-full py-2.5 px-4 bg-white/10 hover:bg-white/15 text-white font-medium text-xs rounded-lg transition-colors border border-white/10 text-center"
            >
              Formulaire de contact
            </button>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-neutral-500">
          <p>© {new Date().getFullYear()} {COMPANY_INFO.name}. Tous droits réservés · Abidjan, Côte d’Ivoire.</p>
          <div className="flex items-center gap-4 text-neutral-400">
            <span>Mode Streetwear</span>
            <span>·</span>
            <span>Vêtements & Sneakers</span>
            <span>·</span>
            <span>Packs Petites Entreprises</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
