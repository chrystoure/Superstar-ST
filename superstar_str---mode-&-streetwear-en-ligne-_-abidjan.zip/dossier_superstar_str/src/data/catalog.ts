export interface Product {
  id: string;
  name: string;
  category: 'vetements' | 'chaussures' | 'accessoires' | 'packs-pro';
  categoryLabel: string;
  price: string;
  priceNum: number;
  description: string;
  image: string;
  badge?: string;
  isPopular?: boolean;
}

export interface ServiceItem {
  id: string;
  title: string;
  subtitle: string;
  target: 'Jeunesse & Particuliers' | 'Petites Entreprises & Revendeurs';
  description: string;
  benefits: string[];
  ctaLabel: string;
  contactSubject: string;
}

export const PRODUCTS: Product[] = [
  {
    id: 'prod-1',
    name: 'Sneakers Orbit Chrome Blue Edition',
    category: 'chaussures',
    categoryLabel: 'Chaussures & Sneakers',
    price: '48 000 FCFA',
    priceNum: 48000,
    description: 'Baskets futuristes à semelle amortissante haute performance, accents bleu électrique et cuir vegan texturé.',
    image: '/src/assets/images/product_luxury_sneakers_1790967778325.jpg',
    badge: 'Best-Seller',
    isPopular: true,
  },
  {
    id: 'prod-2',
    name: 'Hoodie Heavyweight "Superstar Noir Profond"',
    category: 'vetements',
    categoryLabel: 'Vêtements',
    price: '28 000 FCFA',
    priceNum: 28000,
    description: 'Coton peigné lourd 480 GSM, coupe boxy oversize streetwear, finitions chromées et broderie subtile ton sur ton.',
    image: '/src/assets/images/product_oversized_hoodie_1790967788504.jpg',
    badge: 'Tendance Urbaine',
    isPopular: true,
  },
  {
    id: 'prod-3',
    name: 'Pack Accessoires Tech & Streetwear Abidjan',
    category: 'accessoires',
    categoryLabel: 'Accessoires',
    price: '19 500 FCFA',
    priceNum: 19500,
    description: 'Sling bag tactique déperlant, chaîne maillon acier inoxydable 316L et casquette structurée brodée.',
    image: '/src/assets/images/product_urban_accessories_1790967798912.jpg',
    badge: 'Stock Limité',
  },
  {
    id: 'prod-4',
    name: 'Veste Bomber Techwear Réfléchissante',
    category: 'vetements',
    categoryLabel: 'Vêtements',
    price: '36 000 FCFA',
    priceNum: 36000,
    description: 'Tissu coupe-vent déperlant avec inserts réfléchissants, poches cargo modulables et doublure respirante.',
    image: '/src/assets/images/hero_streetwear_abidjan_1790967767459.jpg',
    isPopular: true,
  },
  {
    id: 'prod-5',
    name: 'Sneakers Cyber Low "Abidjan Midnight"',
    category: 'chaussures',
    categoryLabel: 'Chaussures & Sneakers',
    price: '42 000 FCFA',
    priceNum: 42000,
    description: 'Sneakers basses racées et confortables pour le quotidien urbain, semelle crantée tout-terrain.',
    image: '/src/assets/images/product_luxury_sneakers_1790967778325.jpg',
  },
  {
    id: 'prod-6',
    name: 'Pack Starter Boutique Revendeur (Lot de 12 pièces)',
    category: 'packs-pro',
    categoryLabel: 'Petite Entreprise / Gros',
    price: '185 000 FCFA',
    priceNum: 185000,
    description: 'Lot assorti de hoodies, t-shirts graphiques et accessoires à forte marge commerciale pour petites boutiques d’Abidjan.',
    image: '/src/assets/images/about_fashion_studio_1790967812967.jpg',
    badge: 'Offre Pro B2B',
  },
];

export const SERVICES: ServiceItem[] = [
  {
    id: 'srv-1',
    title: 'Vente Directe & Drops Streetwear',
    subtitle: 'Pour les passionnés de mode et la jeunesse urbaine',
    target: 'Jeunesse & Particuliers',
    description: 'Accédez aux collections streetwear les plus recherchées à Abidjan : hoodies oversize, pantalons cargo, sneakers exclusives et accessoires avant-gardistes.',
    benefits: [
      'Articles 100% vérifiés et conformes aux photos réelles',
      'Arrivages réguliers et séries limitées non trouvables ailleurs',
      'Tailles adaptées (S au 3XL, pointures 38 au 46)',
      'Conseils personnalisés de look et de taille par nos stylistes'
    ],
    ctaLabel: 'Commander ou Se Renseigner',
    contactSubject: 'Commande au détail - Vêtements & Chaussures',
  },
  {
    id: 'srv-2',
    title: 'Approvisionnement & Packs Petites Entreprises',
    subtitle: 'Pour les boutiques de quartier, revendeurs et jeunes créateurs',
    target: 'Petites Entreprises & Revendeurs',
    description: 'Vous tenez une boutique ou vendez en ligne à Abidjan ou en Côte d’Ivoire ? SUPERSTAR_STR vous fournit des lots de vêtements et chaussures à prix grossiste compétitifs.',
    benefits: [
      'Tarifs dégressifs adaptés aux petits capitaux de démarrage',
      'Sélection rigoureuse des pièces à fort potentiel de vente rapide',
      'Possibilité de panachage de modèles et tailles selon vos besoins',
      'Facturation claire et approvisionnement récurrent fiable'
    ],
    ctaLabel: 'Demander un Devis Entreprise',
    contactSubject: 'Demande de tarif grossiste / Pack Petite Entreprise',
  },
  {
    id: 'srv-3',
    title: 'Personal Sourcing & Commandes sur Mesure',
    subtitle: 'Vous cherchez une paire rare ou une pièce spécifique ?',
    target: 'Jeunesse & Particuliers',
    description: 'Vous avez vu un vêtement, une paire de sneakers ou un sac tendance sur les réseaux sociaux ? Nous activons notre réseau international pour vous le faire livrer à Abidjan.',
    benefits: [
      'Recherche et validation de la pièce sous 24 à 48h',
      'Devis tout compris (achat + fret + dédouanement + livraison)',
      'Suivi étape par étape de votre commande jusqu’à vos mains',
      'Garantie conformité et inspection minutieuse à l’arrivée'
    ],
    ctaLabel: 'Demander un Article Précis',
    contactSubject: 'Personal Sourcing - Pièce / Paire spécifique',
  },
  {
    id: 'srv-4',
    title: 'Livraison Rapide Abidjan & Expédition Régionale',
    subtitle: 'Un service logistique réactif et sécurisé',
    target: 'Petites Entreprises & Revendeurs',
    description: 'Distribution rapide dans toutes les communes d’Abidjan (Cocody, Marcory, Plateau, Yopougon, Koumassi, Treichville, etc.) et expédition sécurisée vers l’intérieur du pays.',
    benefits: [
      'Livraison le jour même ou sous 24h sur Abidjan',
      'Option de paiement à la réception pour les livraisons Abidjan',
      'Emballage soigné protégeant les vêtements et boîtes à chaussures',
      'Partenariats avec transporteurs fiables pour l’intérieur'
    ],
    ctaLabel: 'Poser une Question Livraison',
    contactSubject: 'Question sur les livraisons et zones desservies',
  },
];

export const TESTIMONIALS = [
  {
    id: 't-1',
    author: 'Kouassi Yves-Armel',
    role: 'Client régulier & Créatif',
    location: 'Abidjan (Cocody Angré)',
    comment: 'Franchement, trouver des sneakers avec cette qualité de finition et des coupes oversize parfaites à Abidjan était un calvaire. Avec SUPERSTAR_STR, la livraison est ultra rapide et les articles sont exactement conformes aux photos.',
    item: 'Sneakers Orbit Chrome + Hoodie Noir',
  },
  {
    id: 't-2',
    author: 'Aïcha Diabaté',
    role: 'Gérante de boutique de mode',
    location: 'Abidjan (Yopougon)',
    comment: 'J’ai commencé avec un petit pack revendeur de 15 pièces pour tester ma clientèle. En 4 jours, tout est parti ! Les prix pour les petites entreprises permettent de dégager une vraie marge. Un partenaire sérieux.',
    item: 'Pack Revendeur B2B',
  },
  {
    id: 't-3',
    author: 'Mohamed Cissé',
    role: 'Passionné de Streetwear',
    location: 'Abidjan (Marcory Zone 4)',
    comment: 'Le service client sur WhatsApp et par formulaire est top. Ils m’ont conseillé pour la pointure et le lendemain ma commande était déposée au bureau. Je recommande à 100%.',
    item: 'Veste Bomber Techwear',
  },
];

export const COMPANY_INFO = {
  name: 'SUPERSTAR_STR',
  tagline: 'Vente en ligne de vêtements, chaussures & mode urbaine',
  phone: '+2250712105180',
  phoneDisplay: '+225 07 12 10 51 80',
  email: 'chrystoure65@icloud.com',
  location: 'Abidjan 01, Côte d’Ivoire',
  openingHours: 'Lundi - Samedi : 08h30 - 20h00',
  whatsappUrl: 'https://wa.me/2250712105180?text=Bonjour%20SUPERSTAR_STR%2C%20je%20souhaite%20des%20informations%20sur%20vos%20articles.',
};
