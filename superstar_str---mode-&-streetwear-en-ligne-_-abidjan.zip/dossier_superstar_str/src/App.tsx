/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Navbar, PageId } from './components/Navbar';
import { Footer } from './components/Footer';
import { HomePage } from './pages/HomePage';
import { AboutPage } from './pages/AboutPage';
import { ServicesPage } from './pages/ServicesPage';
import { ContactPage } from './pages/ContactPage';
import { Product, COMPANY_INFO } from './data/catalog';
import { MessageSquare, ArrowUp } from 'lucide-react';

export default function App() {
  const [currentPage, setCurrentPage] = useState<PageId>('accueil');
  const [contactSubject, setContactSubject] = useState<string>('');
  const [contactMessage, setContactMessage] = useState<string>('');
  const [showScrollTop, setShowScrollTop] = useState(false);

  // Monitor scroll for back to top button
  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 400) {
        setShowScrollTop(true);
      } else {
        setShowScrollTop(false);
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleNavigate = (page: PageId, extraParam?: string) => {
    setCurrentPage(page);
    if (extraParam) {
      setContactSubject(extraParam);
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleProductSelect = (product: Product) => {
    setContactSubject(`Commande : ${product.name} (${product.price})`);
    setContactMessage(`Bonjour SUPERSTAR_STR, je souhaite commander l'article "${product.name}" au tarif de ${product.price}. Veuillez m'indiquer la disponibilité de ma taille/pointure et les modalités de livraison à Abidjan.`);
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-[#07080b] text-neutral-100 flex flex-col font-sans selection:bg-[#00f0ff] selection:text-black">
      
      {/* 1. Header Navigation Bar */}
      <Navbar
        currentPage={currentPage}
        onNavigate={handleNavigate}
      />

      {/* 2. Page Content Switching */}
      <main className="flex-1 pb-16">
        {currentPage === 'accueil' && (
          <HomePage
            onNavigate={handleNavigate}
            onSelectProductForContact={handleProductSelect}
          />
        )}

        {currentPage === 'apropos' && (
          <AboutPage
            onNavigate={handleNavigate}
          />
        )}

        {currentPage === 'services' && (
          <ServicesPage
            onNavigate={handleNavigate}
          />
        )}

        {currentPage === 'contact' && (
          <ContactPage
            initialSubject={contactSubject}
            initialMessage={contactMessage}
          />
        )}
      </main>

      {/* 3. Footer */}
      <Footer onNavigate={handleNavigate} />

      {/* 4. Floating Instant WhatsApp Badge */}
      <aside aria-label="Assistance WhatsApp instantanée" className="fixed bottom-6 right-6 z-40 flex flex-col items-end gap-3 pointer-events-none">
        {showScrollTop && (
          <button
            onClick={scrollToTop}
            aria-label="Retour en haut"
            className="w-10 h-10 rounded-full bg-white/10 hover:bg-white/20 text-white backdrop-blur-md border border-white/10 flex items-center justify-center transition-all shadow-lg pointer-events-auto cursor-pointer"
          >
            <ArrowUp className="w-4 h-4" />
          </button>
        )}

        <a
          href={COMPANY_INFO.whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          aria-label="Discuter directement sur WhatsApp"
          className="group flex items-center gap-2.5 px-4 py-2.5 bg-[#25D366] hover:bg-[#20ba5a] text-black font-bold text-xs rounded-full shadow-[0_4px_20px_rgba(37,211,102,0.4)] transition-all pointer-events-auto transform hover:scale-105 active:scale-95"
        >
          <MessageSquare className="w-4 h-4 shrink-0" />
          <span className="hidden sm:inline">WhatsApp Express</span>
        </a>
      </aside>

    </div>
  );
}
