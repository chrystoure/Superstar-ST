# SUPERSTAR_STR - Site Web Officiel (Abidjan, Côte d'Ivoire)

Bienvenue dans le dossier complet du projet **SUPERSTAR_STR**, la boutique en ligne de streetwear, vêtements, chaussures et articles de mode pour la jeunesse et les petites entreprises d'Abidjan.

---

## 📁 Contenu de ce dossier (`dossier_superstar_str`)

1. **`src/`** : Code source complet de l'application React / TypeScript :
   - `src/components/BrandLogo.tsx` : Logo vectoriel fidèle (faisceau laser bleu cyan, typographie chromée, anneaux orbitaux atomiques).
   - `src/components/Navbar.tsx` : Barre de navigation responsive avec accès direct aux 4 pages.
   - `src/components/ContactForm.tsx` : Formulaire officiel connecté à FormBold (`https://formbold.com/s/3GEqM`).
   - `src/components/Footer.tsx` : Pied de page complet avec coordonnées réelles (+2250712105180, chrystoure65@icloud.com, Abidjan 01).
   - `src/pages/HomePage.tsx` : Page d'accueil optimisée pour la conversion avec vitrine articles et avis clients.
   - `src/pages/AboutPage.tsx` : Page À propos, histoire, vision et engagements.
   - `src/pages/ServicesPage.tsx` : Page Services (détail & packs petites entreprises/revendeurs).
   - `src/pages/ContactPage.tsx` : Page Contact complète avec formulaire, coordonnées et FAQ.
   - `src/data/catalog.ts` : Catalogue de produits en FCFA et informations d'entreprise.
   - `src/assets/images/` : Visuels haute définition streetwear et showroom.

2. **`dist/`** : Version compilée et prête pour la production :
   - Contient les fichiers HTML, CSS et JavaScript minifiés.
   - Peut être directement hébergée sur n'importe quel hébergeur web (Netlify, Vercel, Hostinger, cPanel, Apache, Nginx, etc.).

3. **`superstar_str_archive.tar.gz`** : Archive compressée de tout le projet pour sauvegarde ou transfert facile.

4. **Fichiers de configuration** :
   - `index.html` : Entrée HTML avec polices Syne et Plus Jakarta Sans.
   - `package.json` : Dépendances du projet (React 19, Tailwind CSS, Lucide Icons).
   - `vite.config.ts` & `tsconfig.json` : Configuration Vite et TypeScript.

---

## 🚀 Comment lancer le projet en local (Développement)

```bash
# 1. Installer les dépendances
npm install

# 2. Lancer le serveur de développement local
npm run dev

# 3. Compiler pour la production
npm run build
```

---

## 🌐 Coordonnées de l'entreprise intégrées

- **Téléphone / WhatsApp** : +225 07 12 10 51 80
- **Email** : chrystoure65@icloud.com
- **Localisation** : Abidjan 01, Côte d’Ivoire
- **Formulaire de contact** : FormBold (`https://formbold.com/s/3GEqM`)
